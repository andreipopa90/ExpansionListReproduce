﻿using CommunityToolkit.Mvvm.ComponentModel;
using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.Input;


namespace ExpansionListReproduce.ViewModels
{
    public partial class ListItemViewModel : ObservableObject
    {
        [ObservableProperty]
        private string? _text1;

        [ObservableProperty]
        private string? _text2;
        public ObservableCollection<ControlViewModel> Items { get; } = new ObservableCollection<ControlViewModel>();

        [ObservableProperty]
        public bool _showExpandedView;

        public bool ExpandList => Items.Count > 0;

        [RelayCommand]
        private Task ItemTouch()
        {
            ShowExpandedView = !ShowExpandedView;
            return Task.CompletedTask;
        }
    }
}
