﻿namespace ExpansionListReproduce;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}